﻿namespace Eventures.Data.Seeding
{
    public interface ISeeder
    {
        void Seed();
    }
}